package contact;

/**The Address class

 * 
 * @Author Rashmi and Sanjae
 */
import java.util.*;
public class Address {
	private String addr;
	private String[] address = new String[5];
	
	/**The constructor of the Address class
	 * 
	 * @param location
	 */
	public Address(String location){
		addr = location;
		address = addr.split(";");
	}

	/**Returns a String which is the country
	 * 
	 * @return country
	 */
	public String getCountry(){
		String country = address[address.length - 1];
		return country;
	}

	/**Returns a String which is the address by looping through the address array
	 * and storing the indexes that are not empty to an array list.
	 * It then goes through the array list and stores the address in a String variable 
	 * in a new line. 
	 * @return s1
	 */
	public String toString(){
		ArrayList<String> addressList = new ArrayList<String>();
		
		for (int x = 0; x < address.length; x++) {
			if ( address[x] != null) {
				addressList.add( address[x] );
			}
		}
		
		String s1 = "";
		
		for (String i : addressList){
			s1 += i + "\n";
		}
		
		return s1;
	}
	
	
	/**Returns a String array by looping through the address array and checks if it is not
	 * empty and if not it is added to an array list. 
	 * The array list is then converted to an array of the size if the array list
	 * @return list.toArray(new String[list.size()])
	 */
	public String[] getAddress() {
		ArrayList<String> list = new ArrayList<String>();
		
		for(String addres : this.address) {
			if (! addres.isEmpty()) {
				list.add(addres);
			}
		}
		
		return list.toArray(new String[list.size()]);
		
	}
	
}
