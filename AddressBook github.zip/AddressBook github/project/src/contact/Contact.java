package contact;

/**The Contact class, which is a subclass of the Person class
 * @author Rashmi and Sanjae
 */
import java.util.*;
public class Contact extends Person implements Comparable<Contact>{
	
	private static int count = 0;
	private String alias;
	private Address a1;
	private ArrayList<String> emailsList = new ArrayList<String>();
	private Phone[] phoneList;
	private int counter;
	private int entryNo;
	//private ArrayList<Integer> entryNumber = new ArrayList<Integer>();
	
	
	/**The constructor for the Contact class
	 * The static variable count is also incremented here
	 * @param fname
	 * @param lname
	 * @param gender
	 * @param bday
	 */
	public Contact(String fname, String lname, Gender gender, long bday){
		super(fname, lname, gender, bday);
		this.phoneList = new Phone[5];
		count += 1;
		entryNo = count;
		//entryNumber.add(entryNo);
	} 
	
	/**The another constructor for the Contact class
	 * 
	 * @param fname
	 * @param lname
	 * @param gender
	 * @param nickname
	 * @param location
	 * @param bday
	 */
	public Contact(String fname, String lname, Gender gender, String nickname, String location, long bday) {
		super(fname, lname, gender, bday);
		alias = nickname;
		a1 = new Address(location);
		this.phoneList = new Phone[5];
		count += 1;
		entryNo = count;
	}
	
	/**Returns an integer, which is the static variable count that is incremented before returned
	 * 
	 * @return ++count
	 */
	public int getEntryNo() {
		return entryNo;
	}
	
	public void setEntryNo() {
		entryNo = count;
	}
	
	
	/**Returns the age of a person. This is done by getting the current day, month and year, and then
	 * getting the year, month and day from the date of birth by performing calculations  to get the 
	 * specific part of the date.
	 * The age is then calculated by subtracting the current year from the birthday year, then
	 * comparing if the birthday month is greater than the current month. If true, age is decremented, 
	 * if false the birthday day is compared to current day, if greater then age is decremented 
	 * @return age
	 */
	public int getAge() {
		int now_year = (int) Calendar.getInstance().get(Calendar.YEAR);
		int now_month = (int) Calendar.getInstance().get(Calendar.MONTH);
		int now_date = (int) Calendar.getInstance().get(Calendar.DATE);
		
		int year = (int) this.dob/ 10000;
		int month = (int) (this.dob % 10000) / 100;
		int date = (int) this.dob %100;
		int age = now_year - year;
		if(month > now_month){
			age--;
		}else if((month == now_month) && (date > now_date)) {
				age--;
		}
		
		return age;
	}
	
	/**Returns a String, which is the name by using the an object to represent
	 * the name class to access its function of getting first and last names	 * 
	 * @return name
	 */
	public String getName() {
		String name = "";
		name += n1.getLastName();
		name += ",";
		name += n1.getFirstName();
		return name;
	}
	
	/**Does not return anything, but updates the last name by calling the super method
	 * to access the function to change the last name in the parent class.
	 * 
	 */
	public void updateName(String name) {
		super.changeLastName(name);
	}
	
	/**Does not return anything, but accepts an nickname and makes is the alias for the person
	 * 
	 * @param nickname
	 */
	public void setAlias(String nickname) {
			alias = nickname;
	}
	
	
	/**Returns a string, which is the alias of the person
	 * 
	 * @return
	 */
	public String getAlias() {
		return alias;
	}
	
	/**Does not return anything.
	 * Sets up the object that represents the Address object 
	 * @param location
	 */
	public void setAddress(String location) {
		a1 = new Address(location);
	}
	
	/**Returns a String array, by using the object that represents the Address class to 
	 * call a function from the Address class to get the address
	 * @return a1.getAddress()
	 */
	public String[] getAddress(){
		return a1.getAddress();
	}
	
	/**Does not return anything, just adds an email to the email array list
	 * 
	 * @param email
	 */
	public void addEmail(String email) {
		emailsList.add(email);
	}
	
	/**Does not return anything, just deletes an email from the email  array list
	 * 
	 * @param email
	 */
	public void deleteEmail(String email) {
		emailsList.remove(email);
	}
	
	/**Returns a string array, by converting the email array list to an array the size
	 *  of the list
	 * @return emailsList.toArray(new String[emailsList.size()])
	 */
	public String[] getEmailList() {
		return emailsList.toArray(new String[emailsList.size()]);
	}
	
	/**Does not return anything, just creates an object to represent the Phone class and if
	 * the number of phones is less than 5, the phone number is then added to the phoneList
	 * array. 
	 * The number of phones in the array increments
	 * @param t
	 * @param phone_n
	 */
	public void addPhone(char t, long phone_n) {
		Phone p1 = new Phone(phone_n,t);
		if(this.counter < 5) {
			this.phoneList[this.counter] = p1;
			this.counter++;
		}
	}
	
	/**Does not return anything, but loops through the phoneList array to find if the number
	 * from the parameter exists in the array, and if it does it's index is stored and the loop
	 * is exited. 
	 * The phoneList array is looped through again to shift the elements of the array to the left
	 * and makes its previous index empty. The counter is decremented to know when the end of the 
	 * array is reached
	 * @param num
	 */
	public void deletePhone(long num) {
		int index = 0;
		
		for(int i = 0; i < 5; i++) {
			if(num == this.phoneList[i].getNumber()) {
				index = i;
				break;
			}
		}		
		for(int j = index; j < this.counter; j++) {
			this.phoneList[j] = this.phoneList[j+1];
			this.phoneList[j+1] = null;
		}		
		counter--;
	}
	
	/**Returns a String array, by looping through the phoneList array and the value from the toString
	 * function is stored in the that index of the list array. 
	 * @return list
	 */
	public String[] getPhoneList() {
		String[] list = new String[this.counter];
		
		for(int i = 0; i < this.counter; i++) {
			list[i] = this.phoneList[i].toString();
		}
		return list;
	}
	
	/**
	 * Returns the full details of a contact in the Address Book
	 */
	public String toString() {
		String details = "";
		details += "------------------ Contact Details ------------------\n\n";
		details += "Entry #: " + getEntryNo() + "\n";
		details += "Name: " + getName() + "                   " + "Alias: " + getAlias() + "\n";
		details += "Gender: " + getGender() + "\n";
		details += "Phone #: " + Arrays.toString(getPhoneList()) + "\n";
		details += "Emails: " + Arrays.toString(getEmailList()) + "\n";
		details += "Address:" + Arrays.toString(getAddress()) + "\n";
		
		return details;
	}
	
	public String toString2() {
		String details = "";
		details += getEntryNo() + "%";
		details += n1.getFirstName() + "%";
		details += n1.getLastName() + "%";
		details += getGender() + "%";
		details += getAlias() + "%";
		details += Arrays.toString(getAddress()) + "%";
		details += Arrays.toString(getPhoneList()) + "%";
		details += Arrays.toString(getEmailList()) + "%";
		details += getDOB() +"\n";
		
		return details;
	}
	
	public int compareTo(Contact other) {
		return getName().compareTo(other.getName());
	}
	
}