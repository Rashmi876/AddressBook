//package contact;
//
//import java.awt.BorderLayout;
//import java.awt.Color;
//import java.awt.EventQueue;
//
//import javax.swing.*;
//import javax.swing.border.EmptyBorder;
//import java.awt.GridBagLayout;
//import java.awt.GridBagConstraints;
//import java.awt.Insets;
//import java.awt.Font;
//import java.awt.event.ActionListener;
//import java.awt.event.ActionEvent;
//
//public class Main extends JFrame {
//
//	private JPanel contentPane;
//	private JTextField textField;
//	private JTextField textField_1;
//	private JPasswordField textField_11;
//	private JTextField txtDdmmyyyy;
//	private JTextField textField_2;
//	private JTextField textField_3;
//	private JTextField textField_4;
//
//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Main frame = new Main();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
//
//	/**
//	 * Create the frame.
//	 */
//	public Main() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setBounds(100, 100, 480, 351);
//		contentPane = new JPanel();
//		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//		setContentPane(contentPane);
//		GridBagLayout gbl_contentPane = new GridBagLayout();
//		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
//		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
//		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//		contentPane.setLayout(gbl_contentPane);
//		
//		JLabel label = new JLabel("");
//		GridBagConstraints gbc_label = new GridBagConstraints();
//		gbc_label.insets = new Insets(0, 0, 5, 0);
//		gbc_label.gridx = 7;
//		gbc_label.gridy = 0;
//		contentPane.add(label, gbc_label);
//		
//		JLabel lblLogin = new JLabel("LOGIN");
//		lblLogin.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 24));
//		GridBagConstraints gbc_lblLogin = new GridBagConstraints();
//		gbc_lblLogin.insets = new Insets(0, 0, 5, 5);
//		gbc_lblLogin.gridx = 6;
//		gbc_lblLogin.gridy = 1;
//		contentPane.add(lblLogin, gbc_lblLogin);
//		
//		JLabel lblUsername = new JLabel("USERNAME");
//		lblUsername.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//		GridBagConstraints gbc_lblUsername = new GridBagConstraints();
//		gbc_lblUsername.insets = new Insets(0, 0, 5, 5);
//		gbc_lblUsername.gridx = 6;
//		gbc_lblUsername.gridy = 3;
//		contentPane.add(lblUsername, gbc_lblUsername);
//		
//		textField = new JTextField();
//		GridBagConstraints gbc_textField = new GridBagConstraints();
//		gbc_textField.insets = new Insets(0, 0, 5, 5);
//		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//		gbc_textField.gridx = 6;
//		gbc_textField.gridy = 4;
//		contentPane.add(textField, gbc_textField);
//		textField.setColumns(10);
//		
//		JLabel lblPassword = new JLabel("PASSWORD");
//		lblPassword.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
//		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
//		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
//		gbc_lblPassword.gridx = 6;
//		gbc_lblPassword.gridy = 6;
//		contentPane.add(lblPassword, gbc_lblPassword);
//		
//		textField_11 = new JPasswordField();
//		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
//		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
//		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
//		gbc_textField_1.gridx = 6;
//		gbc_textField_1.gridy = 7;
//		contentPane.add(textField_11, gbc_textField_1);
//		textField_11.setColumns(10);
//		
//		JButton btnSubmit = new JButton("SUBMIT");
//		btnSubmit.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				dispose();
//				JFrame menu =new JFrame();
//				menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//				menu.setBounds(100, 100, 475, 679);
//				contentPane = new JPanel();
//				contentPane.setBackground(Color.CYAN);
//				contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//				menu.setContentPane(contentPane);
//				GridBagLayout gbl_contentPane = new GridBagLayout();
//				gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
//				gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//				gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//				gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//				contentPane.setLayout(gbl_contentPane);
//				
//				JLabel label = new JLabel("");
//				GridBagConstraints gbc_label = new GridBagConstraints();
//				gbc_label.insets = new Insets(0, 0, 5, 5);
//				gbc_label.gridx = 3;
//				gbc_label.gridy = 0;
//				contentPane.add(label, gbc_label);
//				
//				JLabel lblNewLabel = new JLabel("ADDRESS BOOK ");
//				lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 24));
//				GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
//				gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
//				gbc_lblNewLabel.gridx = 7;
//				gbc_lblNewLabel.gridy = 1;
//				contentPane.add(lblNewLabel, gbc_lblNewLabel);
//				
//				JButton btnAddContact = new JButton("ADD CONTACT ");
//				btnAddContact.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
//				btnAddContact.addActionListener(new ActionListener() {
//					
//					
//					public void actionPerformed(ActionEvent arg0) {
//						dispose();
//						JFrame add = new JFrame();
//						
//						add.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//						add.setBounds(100, 100, 600, 550);
//						contentPane = new JPanel();
//						contentPane.setBackground(Color.CYAN);
//						contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//						add.setContentPane(contentPane);
//						GridBagLayout gbl_contentPane = new GridBagLayout();
//						gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						contentPane.setLayout(gbl_contentPane);
//						
//						JLabel lblAddContact = new JLabel("ADD CONTACT");
//						lblAddContact.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblAddContact = new GridBagConstraints();
//						gbc_lblAddContact.gridwidth = 7;
//						gbc_lblAddContact.insets = new Insets(0, 0, 5, 5);
//						gbc_lblAddContact.gridx = 3;
//						gbc_lblAddContact.gridy = 0;
//						contentPane.add(lblAddContact, gbc_lblAddContact);
//						
//						JLabel lblFirstName = new JLabel("FIRST NAME:");
//						lblFirstName.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblFirstName = new GridBagConstraints();
//						gbc_lblFirstName.anchor = GridBagConstraints.EAST;
//						gbc_lblFirstName.insets = new Insets(0, 0, 5, 5);
//						gbc_lblFirstName.gridx = 1;
//						gbc_lblFirstName.gridy = 1;
//						contentPane.add(lblFirstName, gbc_lblFirstName);
//						
//						textField = new JTextField();
//						GridBagConstraints gbc_textField = new GridBagConstraints();
//						gbc_textField.gridwidth = 7;
//						gbc_textField.insets = new Insets(0, 0, 5, 5);
//						gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField.gridx = 3;
//						gbc_textField.gridy = 1;
//						contentPane.add(textField, gbc_textField);
//						textField.setColumns(10);
//						
//						JLabel lblLastName = new JLabel("LAST NAME : ");
//						lblLastName.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblLastName = new GridBagConstraints();
//						gbc_lblLastName.anchor = GridBagConstraints.EAST;
//						gbc_lblLastName.insets = new Insets(0, 0, 5, 5);
//						gbc_lblLastName.gridx = 1;
//						gbc_lblLastName.gridy = 2;
//						contentPane.add(lblLastName, gbc_lblLastName);
//						
//						textField_1 = new JTextField();
//						GridBagConstraints gbc_textField_1 = new GridBagConstraints();
//						gbc_textField_1.gridwidth = 7;
//						gbc_textField_1.insets = new Insets(0, 0, 5, 5);
//						gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField_1.gridx = 3;
//						gbc_textField_1.gridy = 2;
//						contentPane.add(textField_1, gbc_textField_1);
//						textField_1.setColumns(10);
//						
//						JLabel lblGender = new JLabel("GENDER : ");
//						lblGender.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblGender = new GridBagConstraints();
//						gbc_lblGender.anchor = GridBagConstraints.EAST;
//						gbc_lblGender.insets = new Insets(0, 0, 5, 5);
//						gbc_lblGender.gridx = 1;
//						gbc_lblGender.gridy = 3;
//						contentPane.add(lblGender, gbc_lblGender);
//						
//						JRadioButton rdbtnMale = new JRadioButton("MALE");
//						rdbtnMale.setFont(new Font("Tahoma", Font.PLAIN, 20));
//						GridBagConstraints gbc_rdbtnMale = new GridBagConstraints();
//						gbc_rdbtnMale.gridwidth = 2;
//						gbc_rdbtnMale.anchor = GridBagConstraints.WEST;
//						gbc_rdbtnMale.insets = new Insets(0, 0, 5, 5);
//						gbc_rdbtnMale.gridx = 3;
//						gbc_rdbtnMale.gridy = 3;
//						contentPane.add(rdbtnMale, gbc_rdbtnMale);
//						
//						JRadioButton rdbtnFemale = new JRadioButton("FEMALE");
//						rdbtnFemale.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_rdbtnFemale = new GridBagConstraints();
//						gbc_rdbtnFemale.insets = new Insets(0, 0, 5, 5);
//						gbc_rdbtnFemale.gridx = 6;
//						gbc_rdbtnFemale.gridy = 3;
//						contentPane.add(rdbtnFemale, gbc_rdbtnFemale);
//						
//						JLabel lblDateOfBirth = new JLabel("DATE OF BIRTH :");
//						lblDateOfBirth.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblDateOfBirth = new GridBagConstraints();
//						gbc_lblDateOfBirth.anchor = GridBagConstraints.EAST;
//						gbc_lblDateOfBirth.insets = new Insets(0, 0, 5, 5);
//						gbc_lblDateOfBirth.gridx = 1;
//						gbc_lblDateOfBirth.gridy = 4;
//						contentPane.add(lblDateOfBirth, gbc_lblDateOfBirth);
//						
//						txtDdmmyyyy = new JTextField();
//						GridBagConstraints gbc_txtDdmmyyyy = new GridBagConstraints();
//						gbc_txtDdmmyyyy.gridwidth = 7;
//						gbc_txtDdmmyyyy.insets = new Insets(0, 0, 5, 5);
//						gbc_txtDdmmyyyy.fill = GridBagConstraints.HORIZONTAL;
//						gbc_txtDdmmyyyy.gridx = 3;
//						gbc_txtDdmmyyyy.gridy = 4;
//						contentPane.add(txtDdmmyyyy, gbc_txtDdmmyyyy);
//						txtDdmmyyyy.setColumns(10);
//						
//						JLabel lblAddress = new JLabel("ADDRESS:");
//						lblAddress.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblAddress = new GridBagConstraints();
//						gbc_lblAddress.anchor = GridBagConstraints.EAST;
//						gbc_lblAddress.insets = new Insets(0, 0, 5, 5);
//						gbc_lblAddress.gridx = 1;
//						gbc_lblAddress.gridy = 5;
//						contentPane.add(lblAddress, gbc_lblAddress);
//						
//						textField_2 = new JTextField();
//						GridBagConstraints gbc_textField_2 = new GridBagConstraints();
//						gbc_textField_2.gridwidth = 7;
//						gbc_textField_2.insets = new Insets(0, 0, 5, 5);
//						gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField_2.gridx = 3;
//						gbc_textField_2.gridy = 5;
//						contentPane.add(textField_2, gbc_textField_2);
//						textField_2.setColumns(10);
//						
//						JLabel lblEmail = new JLabel("EMAIL : ");
//						lblEmail.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblEmail = new GridBagConstraints();
//						gbc_lblEmail.anchor = GridBagConstraints.EAST;
//						gbc_lblEmail.insets = new Insets(0, 0, 5, 5);
//						gbc_lblEmail.gridx = 1;
//						gbc_lblEmail.gridy = 6;
//						contentPane.add(lblEmail, gbc_lblEmail);
//						
//						textField_3 = new JTextField();
//						GridBagConstraints gbc_textField_3 = new GridBagConstraints();
//						gbc_textField_3.gridwidth = 7;
//						gbc_textField_3.insets = new Insets(0, 0, 5, 5);
//						gbc_textField_3.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField_3.gridx = 3;
//						gbc_textField_3.gridy = 6;
//						contentPane.add(textField_3, gbc_textField_3);
//						textField_3.setColumns(10);
//						
//						JLabel lblTelephone = new JLabel("TELEPHONE #:");
//						lblTelephone.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblTelephone = new GridBagConstraints();
//						gbc_lblTelephone.anchor = GridBagConstraints.EAST;
//						gbc_lblTelephone.insets = new Insets(0, 0, 5, 5);
//						gbc_lblTelephone.gridx = 1;
//						gbc_lblTelephone.gridy = 7;
//						contentPane.add(lblTelephone, gbc_lblTelephone);
//						
//						textField_4 = new JTextField();
//						GridBagConstraints gbc_textField_4 = new GridBagConstraints();
//						gbc_textField_4.gridwidth = 7;
//						gbc_textField_4.insets = new Insets(0, 0, 5, 5);
//						gbc_textField_4.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField_4.gridx = 3;
//						gbc_textField_4.gridy = 7;
//						contentPane.add(textField_4, gbc_textField_4);
//						textField_4.setColumns(10);
//						
//						JButton btnSubmit = new JButton("SUBMIT");
//						btnSubmit.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//							}
//						});
//						
//						JButton btnCancel = new JButton("CANCEL");
//						btnCancel.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//						            add.dispose();
//
//						            menu.setVisible(true);
//							}
//						});
//						btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//						gbc_btnCancel.gridwidth = 3;
//						gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
//						gbc_btnCancel.gridx = 3;
//						gbc_btnCancel.gridy = 10;
//						contentPane.add(btnCancel, gbc_btnCancel);
//						btnSubmit.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//						gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//						gbc_btnSubmit.gridx = 6;
//						gbc_btnSubmit.gridy = 10;
//						contentPane.add(btnSubmit, gbc_btnSubmit);
//						
//						add.setVisible(true);
//						add.pack();
//					}
//				});
//				GridBagConstraints gbc_btnAddContact = new GridBagConstraints();
//				gbc_btnAddContact.insets = new Insets(0, 0, 5, 0);
//				gbc_btnAddContact.gridx = 7;
//				gbc_btnAddContact.gridy = 3;
//				contentPane.add(btnAddContact, gbc_btnAddContact);
//				
//				JButton btnSearchContact = new JButton("SEARCH CONTACT");
//				btnSearchContact.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						menu.dispose();
//						JFrame search = new JFrame();
//						search.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//						search.setBounds(100, 100, 802, 320);
//						contentPane = new JPanel();
//						contentPane.setBackground(Color.CYAN);
//						contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//						search.setContentPane(contentPane);
//						GridBagLayout gbl_contentPane = new GridBagLayout();
//						gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						contentPane.setLayout(gbl_contentPane);
//						
//						JLabel lblSearchOption = new JLabel("SEARCH OPTION");
//						lblSearchOption.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
//						GridBagConstraints gbc_lblSearchOption = new GridBagConstraints();
//						gbc_lblSearchOption.insets = new Insets(0, 0, 5, 0);
//						gbc_lblSearchOption.gridx = 9;
//						gbc_lblSearchOption.gridy = 0;
//						contentPane.add(lblSearchOption, gbc_lblSearchOption);
//						
//						JButton btnSearchByEntry = new JButton("SEARCH BY ENTRY NUMBER");
//						btnSearchByEntry.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								search.dispose();
//								JFrame sBe = new JFrame();
//								
//								sBe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//								sBe.setBounds(100, 100, 870, 367);
//								contentPane = new JPanel();
//								contentPane.setBackground(Color.CYAN);
//								contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//								sBe.setContentPane(contentPane);
//								GridBagLayout gbl_contentPane = new GridBagLayout();
//								gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
//								gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
//								gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								contentPane.setLayout(gbl_contentPane);
//								
//								JLabel lblSearchByEntry = new JLabel("SEARCH BY ENTRY ");
//								lblSearchByEntry.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
//								GridBagConstraints gbc_lblSearchByEntry = new GridBagConstraints();
//								gbc_lblSearchByEntry.insets = new Insets(0, 0, 5, 5);
//								gbc_lblSearchByEntry.gridx = 2;
//								gbc_lblSearchByEntry.gridy = 0;
//								contentPane.add(lblSearchByEntry, gbc_lblSearchByEntry);
//								
//								JLabel lblEnter = new JLabel("ENTER ENTRY NUMBER");
//								lblEnter.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_lblEnter = new GridBagConstraints();
//								gbc_lblEnter.anchor = GridBagConstraints.EAST;
//								gbc_lblEnter.insets = new Insets(0, 0, 5, 5);
//								gbc_lblEnter.gridx = 1;
//								gbc_lblEnter.gridy = 1;
//								contentPane.add(lblEnter, gbc_lblEnter);
//								
//								textField = new JTextField();
//								GridBagConstraints gbc_textField = new GridBagConstraints();
//								gbc_textField.gridwidth = 2;
//								gbc_textField.insets = new Insets(0, 0, 5, 5);
//								gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//								gbc_textField.gridx = 2;
//								gbc_textField.gridy = 1;
//								contentPane.add(textField, gbc_textField);
//								textField.setColumns(10);
//								
//								JButton btnCancel = new JButton("CANCEL");
//								btnCancel.addActionListener(new ActionListener() {
//									public void actionPerformed(ActionEvent e) {
//										sBe.dispose();
//										menu.setVisible(true);
//									}
//								});
//								btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//								gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
//								gbc_btnCancel.gridx = 1;
//								gbc_btnCancel.gridy = 3;
//								contentPane.add(btnCancel, gbc_btnCancel);
//								
//								JButton btnSubmit = new JButton("SUBMIT");
//								btnSubmit.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//								gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//								gbc_btnSubmit.gridx = 3;
//								gbc_btnSubmit.gridy = 3;
//								contentPane.add(btnSubmit, gbc_btnSubmit);
//								sBe.setVisible(true);
//								sBe.pack();
//							}
//						});
//						btnSearchByEntry.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnSearchByEntry = new GridBagConstraints();
//						gbc_btnSearchByEntry.insets = new Insets(0, 0, 5, 0);
//						gbc_btnSearchByEntry.gridx = 9;
//						gbc_btnSearchByEntry.gridy = 2;
//						contentPane.add(btnSearchByEntry, gbc_btnSearchByEntry);
//						
//						JButton btnSearchByEmail = new JButton("SEARCH BY EMAIL");
//						btnSearchByEmail.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								search.dispose();
//								JFrame sn = new JFrame();
//								sn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//								sn.setBounds(100, 100, 706, 332);
//								contentPane = new JPanel();
//								contentPane.setBackground(Color.CYAN);
//								contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//								sn.setContentPane(contentPane);
//								GridBagLayout gbl_contentPane = new GridBagLayout();
//								gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
//								gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
//								gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								contentPane.setLayout(gbl_contentPane);
//								
//								JLabel lblSearchBy = new JLabel("SEARCH BY EMAIL");
//								lblSearchBy.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
//								GridBagConstraints gbc_lblSearchBy = new GridBagConstraints();
//								gbc_lblSearchBy.insets = new Insets(0, 0, 5, 5);
//								gbc_lblSearchBy.gridx = 2;
//								gbc_lblSearchBy.gridy = 0;
//								contentPane.add(lblSearchBy, gbc_lblSearchBy);
//								
//								JLabel lblEnterEmail = new JLabel("ENTER EMAIL : ");
//								lblEnterEmail.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_lblEnterEmail = new GridBagConstraints();
//								gbc_lblEnterEmail.anchor = GridBagConstraints.EAST;
//								gbc_lblEnterEmail.insets = new Insets(0, 0, 5, 5);
//								gbc_lblEnterEmail.gridx = 1;
//								gbc_lblEnterEmail.gridy = 1;
//								contentPane.add(lblEnterEmail, gbc_lblEnterEmail);
//								
//								textField = new JTextField();
//								GridBagConstraints gbc_textField = new GridBagConstraints();
//								gbc_textField.gridwidth = 2;
//								gbc_textField.insets = new Insets(0, 0, 5, 5);
//								gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//								gbc_textField.gridx = 2;
//								gbc_textField.gridy = 1;
//								contentPane.add(textField, gbc_textField);
//								textField.setColumns(10);
//								
//								JButton btnCancel = new JButton("CANCEL");
//								btnCancel.addActionListener(new ActionListener() {
//									public void actionPerformed(ActionEvent e) {
//										sn.dispose();
//										menu.setVisible(true);
//									}
//								});
//								btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//								gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
//								gbc_btnCancel.gridx = 1;
//								gbc_btnCancel.gridy = 3;
//								contentPane.add(btnCancel, gbc_btnCancel);
//								
//								JButton btnSubmit = new JButton("SUBMIT");
//								btnSubmit.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//								gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//								gbc_btnSubmit.gridx = 3;
//								gbc_btnSubmit.gridy = 3;
//								contentPane.add(btnSubmit, gbc_btnSubmit);
//								sn.setVisible(true);
//								sn.pack();
//							}
//						});
//						btnSearchByEmail.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnSearchByEmail = new GridBagConstraints();
//						gbc_btnSearchByEmail.insets = new Insets(0, 0, 5, 0);
//						gbc_btnSearchByEmail.gridx = 9;
//						gbc_btnSearchByEmail.gridy = 4;
//						contentPane.add(btnSearchByEmail, gbc_btnSearchByEmail);
//						
//						JButton btnCancel = new JButton("CANCEL");
//						btnCancel.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								search.dispose();
//								menu.setVisible(true);
//							}
//						});
//						btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//						gbc_btnCancel.gridx = 9;
//						gbc_btnCancel.gridy = 7;
//						contentPane.add(btnCancel, gbc_btnCancel);
//						search.setVisible(true);
//						search.pack();
//					}
//				});
//				btnSearchContact.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//				GridBagConstraints gbc_btnSearchContact = new GridBagConstraints();
//				gbc_btnSearchContact.insets = new Insets(0, 0, 5, 0);
//				gbc_btnSearchContact.gridx = 7;
//				gbc_btnSearchContact.gridy = 6;
//				contentPane.add(btnSearchContact, gbc_btnSearchContact);
//				
//				JButton btnUpdateContact = new JButton("UPDATE CONTACT");
//				btnUpdateContact.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						menu.dispose();
//						JFrame up = new JFrame();
//						
//						up.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//						up.setBounds(100, 100, 792, 598);
//						contentPane = new JPanel();
//						contentPane.setBackground(Color.CYAN);
//						contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//						up.setContentPane(contentPane);
//						GridBagLayout gbl_contentPane = new GridBagLayout();
//						gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						contentPane.setLayout(gbl_contentPane);
//						
//						JLabel lblNewLabel = new JLabel("UPDATE CONTACT");
//						lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
//						GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
//						gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
//						gbc_lblNewLabel.gridx = 2;
//						gbc_lblNewLabel.gridy = 0;
//						contentPane.add(lblNewLabel, gbc_lblNewLabel);
//						
//						JLabel lblNewLabel_1 = new JLabel("ENTER ENTRY NO : ");
//						lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
//						gbc_lblNewLabel_1.anchor = GridBagConstraints.WEST;
//						gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
//						gbc_lblNewLabel_1.gridx = 1;
//						gbc_lblNewLabel_1.gridy = 2;
//						contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
//						
//						textField = new JTextField();
//						GridBagConstraints gbc_textField = new GridBagConstraints();
//						gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField.gridwidth = 5;
//						gbc_textField.insets = new Insets(0, 0, 5, 0);
//						gbc_textField.gridx = 2;
//						gbc_textField.gridy = 2;
//						contentPane.add(textField, gbc_textField);
//						textField.setColumns(10);
//						
//						JLabel lblNewLabel_2 = new JLabel("ATTRIBUTE TO UPDATE : ");
//						lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
//						gbc_lblNewLabel_2.anchor = GridBagConstraints.WEST;
//						gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
//						gbc_lblNewLabel_2.gridx = 1;
//						gbc_lblNewLabel_2.gridy = 4;
//						contentPane.add(lblNewLabel_2, gbc_lblNewLabel_2);
//						
//						textField_1 = new JTextField();
//						GridBagConstraints gbc_textField_1 = new GridBagConstraints();
//						gbc_textField_1.gridwidth = 5;
//						gbc_textField_1.insets = new Insets(0, 0, 5, 0);
//						gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField_1.gridx = 2;
//						gbc_textField_1.gridy = 4;
//						contentPane.add(textField_1, gbc_textField_1);
//						textField_1.setColumns(10);
//						
//						JLabel lblNewLabel_3 = new JLabel("ENTER NEW ATTRIBUTE :");
//						lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
//						gbc_lblNewLabel_3.anchor = GridBagConstraints.WEST;
//						gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
//						gbc_lblNewLabel_3.gridx = 1;
//						gbc_lblNewLabel_3.gridy = 6;
//						contentPane.add(lblNewLabel_3, gbc_lblNewLabel_3);
//						
//						textField_2 = new JTextField();
//						GridBagConstraints gbc_textField_2 = new GridBagConstraints();
//						gbc_textField_2.gridwidth = 5;
//						gbc_textField_2.insets = new Insets(0, 0, 5, 0);
//						gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
//						gbc_textField_2.gridx = 2;
//						gbc_textField_2.gridy = 6;
//						contentPane.add(textField_2, gbc_textField_2);
//						textField_2.setColumns(10);
//						
//						JButton btnSubmit = new JButton("SUBMIT");
//						btnSubmit.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//							}
//						});
//						btnSubmit.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//						gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//						gbc_btnSubmit.gridx = 1;
//						gbc_btnSubmit.gridy = 12;
//						contentPane.add(btnSubmit, gbc_btnSubmit);
//						
//						JButton btnCancel = new JButton("CANCEL");
//						btnCancel.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								up.dispose();
//								menu.setVisible(true);
//							}
//						});
//						btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//						gbc_btnCancel.gridx = 6;
//						gbc_btnCancel.gridy = 12;
//						contentPane.add(btnCancel, gbc_btnCancel);
//						up.setVisible(true);
//						up.pack();
//					}
//				});
//				btnUpdateContact.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//				GridBagConstraints gbc_btnUpdateContact = new GridBagConstraints();
//				gbc_btnUpdateContact.insets = new Insets(0, 0, 5, 0);
//				gbc_btnUpdateContact.gridx = 7;
//				gbc_btnUpdateContact.gridy = 9;
//				contentPane.add(btnUpdateContact, gbc_btnUpdateContact);
//				
//				JButton btnDeleteContact = new JButton("DELETE CONTACT");
//				btnDeleteContact.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						menu.dispose();
//						JFrame del = new JFrame();
//						del.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//						del.setBounds(100, 100, 759, 522);
//						contentPane = new JPanel();
//						contentPane.setBackground(Color.CYAN);
//						contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//						del.setContentPane(contentPane);
//						GridBagLayout gbl_contentPane = new GridBagLayout();
//						gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						contentPane.setLayout(gbl_contentPane);
//						
//						JLabel lblDelete = new JLabel("Delete");
//						lblDelete.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 24));
//						GridBagConstraints gbc_lblDelete = new GridBagConstraints();
//						gbc_lblDelete.insets = new Insets(0, 0, 5, 5);
//						gbc_lblDelete.gridx = 8;
//						gbc_lblDelete.gridy = 1;
//						contentPane.add(lblDelete, gbc_lblDelete);
//						
//						JButton btnDelete = new JButton("Delete Using Email");
//						btnDelete.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						btnDelete.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								del.dispose();
//								JFrame edel = new JFrame();
//								edel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//								edel.setBounds(100, 100, 607, 372);
//								contentPane = new JPanel();
//								contentPane.setBackground(Color.CYAN);
//								contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//								edel.setContentPane(contentPane);
//								GridBagLayout gbl_contentPane = new GridBagLayout();
//								gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//								gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
//								gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								contentPane.setLayout(gbl_contentPane);
//								
//								JLabel lblDeleteUsingEmail = new JLabel("DELETE USING EMAIL");
//								lblDeleteUsingEmail.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
//								GridBagConstraints gbc_lblDeleteUsingEmail = new GridBagConstraints();
//								gbc_lblDeleteUsingEmail.gridwidth = 2;
//								gbc_lblDeleteUsingEmail.insets = new Insets(0, 0, 5, 5);
//								gbc_lblDeleteUsingEmail.gridx = 3;
//								gbc_lblDeleteUsingEmail.gridy = 0;
//								contentPane.add(lblDeleteUsingEmail, gbc_lblDeleteUsingEmail);
//								
//								JLabel lblEnterEmailAddress = new JLabel("ENTER EMAIL ADDRESS : ");
//								lblEnterEmailAddress.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_lblEnterEmailAddress = new GridBagConstraints();
//								gbc_lblEnterEmailAddress.gridwidth = 2;
//								gbc_lblEnterEmailAddress.anchor = GridBagConstraints.EAST;
//								gbc_lblEnterEmailAddress.insets = new Insets(0, 0, 5, 5);
//								gbc_lblEnterEmailAddress.gridx = 1;
//								gbc_lblEnterEmailAddress.gridy = 2;
//								contentPane.add(lblEnterEmailAddress, gbc_lblEnterEmailAddress);
//								
//								textField = new JTextField();
//								GridBagConstraints gbc_textField = new GridBagConstraints();
//								gbc_textField.gridwidth = 4;
//								gbc_textField.insets = new Insets(0, 0, 5, 5);
//								gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//								gbc_textField.gridx = 3;
//								gbc_textField.gridy = 2;
//								contentPane.add(textField, gbc_textField);
//								textField.setColumns(10);
//								
//								JButton btnCancel = new JButton("CANCEL");
//								btnCancel.addActionListener(new ActionListener() {
//									public void actionPerformed(ActionEvent e) {
//										edel.dispose();
//										del.setVisible(true);
//									}
//								});
//								btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//								gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
//								gbc_btnCancel.gridx = 2;
//								gbc_btnCancel.gridy = 5;
//								contentPane.add(btnCancel, gbc_btnCancel);
//								
//								JButton btnSubmit = new JButton("SUBMIT");
//								btnSubmit.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//								gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//								gbc_btnSubmit.gridx = 6;
//								gbc_btnSubmit.gridy = 5;
//								contentPane.add(btnSubmit, gbc_btnSubmit);
//								edel.setVisible(true);
//								edel.pack();
//							}
//						});
//						GridBagConstraints gbc_btnDelete = new GridBagConstraints();
//						gbc_btnDelete.insets = new Insets(0, 0, 5, 5);
//						gbc_btnDelete.gridx = 8;
//						gbc_btnDelete.gridy = 3;
//						contentPane.add(btnDelete, gbc_btnDelete);
//						
//						JButton btnDeleteUsingContact = new JButton("Delete Using Contact");
//						btnDeleteUsingContact.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								del.dispose();
//								JFrame ndel = new JFrame();
//								ndel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//								ndel.setBounds(100, 100, 825, 497);
//								contentPane = new JPanel();
//								contentPane.setBackground(Color.CYAN);
//								contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//								ndel.setContentPane(contentPane);
//								GridBagLayout gbl_contentPane = new GridBagLayout();
//								gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
//								gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
//								gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
//								gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//								contentPane.setLayout(gbl_contentPane);
//								
//								JLabel lblDeleteUsingPhone = new JLabel("DELETE USING PHONE NUMBER");
//								lblDeleteUsingPhone.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
//								GridBagConstraints gbc_lblDeleteUsingPhone = new GridBagConstraints();
//								gbc_lblDeleteUsingPhone.insets = new Insets(0, 0, 5, 5);
//								gbc_lblDeleteUsingPhone.gridx = 2;
//								gbc_lblDeleteUsingPhone.gridy = 0;
//								contentPane.add(lblDeleteUsingPhone, gbc_lblDeleteUsingPhone);
//								
//								JLabel lblEnterPhoneNumber = new JLabel("ENTER PHONE NUMBER : ");
//								lblEnterPhoneNumber.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_lblEnterPhoneNumber = new GridBagConstraints();
//								gbc_lblEnterPhoneNumber.anchor = GridBagConstraints.EAST;
//								gbc_lblEnterPhoneNumber.insets = new Insets(0, 0, 5, 5);
//								gbc_lblEnterPhoneNumber.gridx = 1;
//								gbc_lblEnterPhoneNumber.gridy = 1;
//								contentPane.add(lblEnterPhoneNumber, gbc_lblEnterPhoneNumber);
//								
//								textField = new JTextField();
//								GridBagConstraints gbc_textField = new GridBagConstraints();
//								gbc_textField.insets = new Insets(0, 0, 5, 5);
//								gbc_textField.fill = GridBagConstraints.HORIZONTAL;
//								gbc_textField.gridx = 2;
//								gbc_textField.gridy = 1;
//								contentPane.add(textField, gbc_textField);
//								textField.setColumns(10);
//								
//								JButton btnCancel = new JButton("CANCEL");
//								btnCancel.addActionListener(new ActionListener() {
//									public void actionPerformed(ActionEvent e) {
//										ndel.dispose();
//										del.setVisible(true);
//									}
//								});
//								btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//								gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
//								gbc_btnCancel.gridx = 1;
//								gbc_btnCancel.gridy = 3;
//								contentPane.add(btnCancel, gbc_btnCancel);
//								
//								JButton btnSubmit = new JButton("SUBMIT");
//								btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 16));
//								GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//								gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//								gbc_btnSubmit.gridx = 3;
//								gbc_btnSubmit.gridy = 3;
//								contentPane.add(btnSubmit, gbc_btnSubmit);
//								ndel.setVisible(true);
//								ndel.pack();
//							}
//						});
//						btnDeleteUsingContact.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnDeleteUsingContact = new GridBagConstraints();
//						gbc_btnDeleteUsingContact.insets = new Insets(0, 0, 5, 5);
//						gbc_btnDeleteUsingContact.gridx = 8;
//						gbc_btnDeleteUsingContact.gridy = 5;
//						contentPane.add(btnDeleteUsingContact, gbc_btnDeleteUsingContact);
//						
//						JButton btnGoBack = new JButton("Back");
//						btnGoBack.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								del.dispose();
//								menu.setVisible(true);
//							}
//						});
//						btnGoBack.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnGoBack = new GridBagConstraints();
//						gbc_btnGoBack.insets = new Insets(0, 0, 5, 5);
//						gbc_btnGoBack.gridx = 8;
//						gbc_btnGoBack.gridy = 9;
//						contentPane.add(btnGoBack, gbc_btnGoBack);
//						del.setVisible(true);
//						del.pack();
//					}
//				});
//				btnDeleteContact.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//				GridBagConstraints gbc_btnDeleteContact = new GridBagConstraints();
//				gbc_btnDeleteContact.insets = new Insets(0, 0, 5, 0);
//				gbc_btnDeleteContact.gridx = 7;
//				gbc_btnDeleteContact.gridy = 12;
//				contentPane.add(btnDeleteContact, gbc_btnDeleteContact);
//				
//				JButton btnExit = new JButton("EXIT");
//				btnExit.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						dispose();
//						System.exit(0);
//				    }
//				});
//				btnExit.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//				GridBagConstraints gbc_btnExit = new GridBagConstraints();
//				gbc_btnExit.gridx = 7;
//				gbc_btnExit.gridy = 18;
//				contentPane.add(btnExit, gbc_btnExit);
//				
//				JButton btnSortContact = new JButton("SORT CONTACT");
//				btnSortContact.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						menu.dispose();
//						JFrame sort = new JFrame();
//						sort.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//						sort.setBounds(100, 100, 821, 518);
//						contentPane = new JPanel();
//						contentPane.setBackground(Color.CYAN);
//						contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//						sort.setContentPane(contentPane);
//						GridBagLayout gbl_contentPane = new GridBagLayout();
//						gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//						gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
//						contentPane.setLayout(gbl_contentPane);
//						
//						JLabel lblDisplay = new JLabel("DISPLAY ");
//						lblDisplay.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 24));
//						GridBagConstraints gbc_lblDisplay = new GridBagConstraints();
//						gbc_lblDisplay.insets = new Insets(0, 0, 5, 5);
//						gbc_lblDisplay.gridx = 10;
//						gbc_lblDisplay.gridy = 1;
//						contentPane.add(lblDisplay, gbc_lblDisplay);
//						
//						JButton btnDisplayContactsBy = new JButton("Display Contacts by Entry No.");
//						btnDisplayContactsBy.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnDisplayContactsBy = new GridBagConstraints();
//						gbc_btnDisplayContactsBy.insets = new Insets(0, 0, 5, 5);
//						gbc_btnDisplayContactsBy.gridx = 10;
//						gbc_btnDisplayContactsBy.gridy = 4;
//						contentPane.add(btnDisplayContactsBy, gbc_btnDisplayContactsBy);
//						
//						JButton btnDisplayContactsBy_1 = new JButton("Display Contacts by Name");
//						btnDisplayContactsBy_1.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//							}
//						});
//						btnDisplayContactsBy_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnDisplayContactsBy_1 = new GridBagConstraints();
//						gbc_btnDisplayContactsBy_1.insets = new Insets(0, 0, 5, 5);
//						gbc_btnDisplayContactsBy_1.gridx = 10;
//						gbc_btnDisplayContactsBy_1.gridy = 7;
//						contentPane.add(btnDisplayContactsBy_1, gbc_btnDisplayContactsBy_1);
//						
//						
//						JButton btnCancel = new JButton("Cancel");
//						btnCancel.addActionListener(new ActionListener() {
//							public void actionPerformed(ActionEvent e) {
//								sort.dispose();
//								menu.setVisible(true);
//							}
//						});
//						btnCancel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//						GridBagConstraints gbc_btnCancel = new GridBagConstraints();
//						gbc_btnCancel.gridx = 7;
//						gbc_btnCancel.gridy = 10;
//						contentPane.add(btnCancel, gbc_btnCancel);
//						sort.setVisible(true);
//						sort.pack();
//					}
//				});
//				btnSortContact.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
//				GridBagConstraints gbc_btnSortContact = new GridBagConstraints();
//				gbc_btnSortContact.fill = GridBagConstraints.HORIZONTAL;
//				gbc_btnSortContact.insets = new Insets(0, 0, 5, 0);
//				gbc_btnSortContact.gridx = 7;
//				gbc_btnSortContact.gridy = 15;
//				contentPane.add(btnSortContact, gbc_btnSortContact);
//				
//				menu.setVisible(true);
//				menu.pack();
//			}
//		});
//		
//		btnSubmit.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
//		GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
//		gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
//		gbc_btnSubmit.gridx = 6;
//		gbc_btnSubmit.gridy = 9;
//		contentPane.add(btnSubmit, gbc_btnSubmit);
//		
//		
//	}
//
//}
