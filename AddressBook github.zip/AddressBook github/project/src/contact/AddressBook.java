package contact;

import java.util.*;
import java.io.*;
import java.lang.*;

/**
 * Provides operations to manage contacts
 * @author Rashmi and Sanjae
 *
 */
public class AddressBook{
	//private String[] c_info = new String[9];
	//private ArrayList<Contact>contactList;
	private DataManager dm = new DataManager();
	//private TextInterface ti = new TextInterface();
	private ArrayList<Contact> fromFile = new ArrayList<>();
	private ArrayList<Contact> workingFile = new ArrayList<>();
	
	
	/**
	 * The constructor for the AddressBook class
	 */
	public AddressBook() {
		workingFile = getWorkingFile();	
	}
	
	/**
	 * Creates a new contact based on the the arguments given,
	 * then adds the new contact to the contact list
	 * @param firstName
	 * @param lastName
	 * @param gender
	 * @param nickname
	 * @param location
	 * @param bday
	 */
	public void addContact(String firstName, String lastName, Gender gender, String nickname, String location, long bday) {
		Contact c1 = new Contact(firstName, lastName, gender, nickname, location, bday);
		getWorkingFile().add(c1);
		/*for(Contact info : contactList) {
			System.out.println(info.getName());
			System.out.println(info.getGender());
			System.out.println(info.getAlias());
			System.out.println(Arrays.toString(info.getAddress()));	//should to come from contact instead of address
			System.out.println(info.getDOB());
		}*/
		//do we send this to the file
	}
	
	/**
	 * Searches for a contact based on an entry number, when the entry number is found
	 * the contact's details will be returned
	 * @param key
	 * @return display
	 */
	public String search(int key) {
		//contactList
		//setEntryNo(key);
		fromFile = dm.readFile("contactinfo.txt");
		String display = "";
		for (Contact info : getWorkingFile()) {	//should it read from the file to get the information
			if(info.getEntryNo() == key) {
				display = info.toString();
				break;
			}
		}
		return display;
		//System.out.println("Entry Number does not exist");	
	}
	
	/**
	 * Searches for a contact based on an email address, and if the email address is found
	 * the contact's details are displayed
	 * @param key
	 * @return display2
	 */
	public String search(String key) {
			fromFile = dm.readFile("contactinfo.txt");
			String display2 = "";
			for (Contact info : getWorkingFile()) {
				String[] emails = info.getEmailList();
				for(int i = 0; i < emails.length; i++) {
					if(emails[i].equals(key)) {
						display2 = info.toString();
					}
					else {
						i++;
					}
					System.out.println("Email does not exist");
				}
			}
			 return display2;
				
			}
	
	/**
	 * This method changes a contact's last name. It checks the list of contacts to see if the
	 * entry number, which is the key, if it exists. If it does the last name of that contact
	 * is changed.
	 * @param key
	 * @param newLName
	 */
	public void changeLastName(int key, String newLName) {
		for (Contact c : getWorkingFile()) {
			if (c.getEntryNo() == key) {
				System.out.println("Change successful");
				c.updateName(newLName);
			}
			else {
				System.out.println("Entry # doesnt exist");
			}
		}
		
	}
	
	/**
	 * This method is to change a contact's alias. First it checks if the alias is available.
	 * If it is not, an appropriate message is displayed, if it is available the entry number
	 * is checked to find the contact, then their alias is changed.
	 * @param key
	 * @param newalias
	 */
	public void changeAlias(int key, String newalias) {	
		boolean available = true;
		
		for (Contact c : getWorkingFile()) {
			if(c.getAlias().equals(newalias)) {
				System.out.println("This alias already exists");
				available = false;
			}
		}
		
		if(available) {
			for(Contact c : getWorkingFile()) {
				if(c.getEntryNo() == key) {
					c.setAlias(newalias);
					//dm.writeToFile("contactinfo.txt", getContactList());
				}
			}
		}
	}
	
	/**
	 * This method changes the address of a specified contact(based on entry number).
	 * It gets the current address of the contact and sets the array it is stored in
	 * to null, then puts the new address into the array
	 * @param key
	 * @param location
	 */
	public void changeAddress(int key, String location) {
		for (Contact c : getWorkingFile()) {
			if(c.getEntryNo() == key) {
				c.setAddress(null);
				c.setAddress(location);	
				//dm.writeToFile("contactinfo.txt", getContactList());
				System.out.println("Change successful");
			}
		}
	}
	
	/**
	 * Allows for a phone number to be added to the array of phone numbers.
	 * The phone number can only be added if the number does not already exist
	 * @param key
	 * @param newNo
	 * @param newType
	 */
	public void addPhoneNo(int key, long newNo, char newType) {
		Phone p = new Phone(newNo, newType);
		for (Contact c : getWorkingFile()) {
			if(c.getEntryNo() == key) {
				String[] arr = new String[c.getPhoneList().length];
				for(int count = 0; count < c.getPhoneList().length; count++) {
					arr[count] = c.getPhoneList()[count];
				}
				for (int i = 0; i < arr.length; i++) {
					if(arr[i].equals(p)) {
						System.out.println("Number already exists");
					}
					else {
						c.addPhone(newType, newNo);
						//dm.writeToFile("contactinfo.txt", getContactList());
						System.out.println("Number added");
					}
				}
			}
		}
	}
	
	/**
	 * Allows for a number to be deleted for a specific contact. Appropriate messages
	 * are displayed if the number was removed, or if it does not exist
	 * @param key
	 * @param number
	 * @param type
	 */
	public void deleteNumber(int key, long number, char type) {
		Phone p = new Phone(number, type);
		for (Contact c : getWorkingFile()) {
			if(c.getEntryNo() == key) {
				String[] arr = c.getPhoneList();
				for (int i = 0; i < arr.length; i++) {
					if(arr[i].equals(p)) {
						c.deletePhone(number);
						//dm.writeToFile("contactinfo.txt", getContactList());
						System.out.println("Number successfully deleted");
					}
					else {
						System.out.println("Number does not exist");
					}
				}
			}
		}
	}
	
	/**
	 * Allows for an email to be added for a specific contact. It can only be
	 * added if the email does not already exist. Appropriate messages are 
	 * displayed if the email does or does not exist
	 * @param key
	 * @param email
	 */
	public void addEmail(int key, String email) {
		for (Contact c : getWorkingFile()) {
			if(c.getEntryNo() == key) {
				String[] arr = c.getEmailList();
				for (int i = 0; i < arr.length; i++) {
					if((arr[i].equals(email))) {
						System.out.println("Email address already exists");
					}
					else {
						c.addEmail(email);
						//dm.writeToFile("contactinfo.txt", getContactList());
						System.out.println("Email added");
					}
				}
			}
		}
	}
	
	/**
	 * Allow for an email for a specific contact to be deleted. Appropriate
	 * messages are displayed if a contact is deleted and if the email does
	 * not exists
	 * 
	 * @param key
	 * @param email
	 */
	public void deleteEmail(int key, String email) {
		for (Contact c : getWorkingFile()) {
			if(c.getEntryNo() == key) {
				String[] arr = c.getEmailList();
				for (int i = 0; i < arr.length; i++) {
					if((arr[i].equals(email))) {
						c.deleteEmail(email);
						//dm.writeToFile("contactinfo.txt", getContactList());
						System.out.println("Email sucessfully deleted");
					}
					else {
						System.out.println("Email address does not exist");
					}
				}
			}
		}
	}
	
	/**
	 * The comparator for sorting the Contact List by Entry Number
	 */
	public static Comparator<Contact> ContactComparator = new Comparator<Contact>() {
		/**
		 * Takes 2 contacts whose entry number will be compared. The result of the comparison is returned.
		 * @param c1
		 * @param c2
		 * @return n1.compareTo(n2)
		 */
		public int compare(Contact c1, Contact c2) {
			Integer n1 = c1.getEntryNo();
			Integer n2 = c2.getEntryNo();
			return n1.compareTo(n2);
		}
	};
	
	/**
	 * Uses the the Collections sort method to sort the Contact List by Entry Number,
	 * which was specified by the comparator interface. It returns the entry #, name,
	 * gender and email address for each contact.
	 * @return toString()
	 */
	public String displaybyEntryNo(){
		Collections.sort(getWorkingFile(), AddressBook.ContactComparator);
		return toString();
	}
	
	/**
	 * Uses the Collection sort method to sort the Contact List by Name which was done in
	 * the Contact Class by the comparable interface. It returns the entry #, name, gender
	 * and email address for each contact.
	 * @return toString()
	 */
	public String displaybyName() {
		Collections.sort(getWorkingFile());
		return toString();
	}
	
	@Override
	/**
	 * Displaying a contact's entry #, name, emails, address.
	 * @return details
	 */
	public String toString() {
		String details = "";
		for(Contact c : getWorkingFile()) {
			details += "------------------ Contact Details ------------------\n\n";
			details += "Entry #: " + c.getEntryNo() + "\n";
			details += "Name: " + c.getName() + "\n";
			details += "Emails: " + Arrays.toString(c.getEmailList()) + "\n";
			details += "Address:" + Arrays.toString(c.getAddress()) + "\n";
		}
		return details;
	}
	
	/**
	 * Deletes a contact based on entry number. The contact list is sorted and binary search
	 * is carried out on the list. When the contact's entry number is found they are removed.
	 * Appropriate messages are displayed if the contact's entry number is found or not.
	 * @param key
	 */
	public void deletebyEntryNo(int key) {
		ArrayList<Integer> carr= new ArrayList<>();;
		int[] carr1 = new int[carr.size()];
		int count=0;
		Collections.sort(getWorkingFile(), AddressBook.ContactComparator);
		for(Contact c : getWorkingFile()) {
			carr1[count]=c.getEntryNo();
			count++;
		}
		
		int result = Arrays.binarySearch(carr1, key);
		
		if(result >= 0) {
			getWorkingFile().remove(getWorkingFile().get(result));
			//dm.writeToFile("contactinfo.txt", getContactList());
			System.out.println("Contact successfully deleted");
		}
		else {
			System.out.println("Entry Number Invalid");
		}
	}
	
	/**
	 * Deletes a contact based on an email. The contacts are searched in the contact list, if that specific
	 * contact contains the email specified, then they are deleted. Appropriate messages are displayed if
	 * the contact's email is found or not.
	 * @param email
	 */
	public void deletebyEmail(String email) {
		for(Contact c : getWorkingFile()) {
			String[] arr = c.getEmailList();
			for (int i = 0; i < arr.length; i++) {
				if((arr[i].equals(email))) {
					c.deleteEmail(email);;
					System.out.println("Contact sucessfully deleted");
				}
				else {
					System.out.println("Email address does not exist");
				}
			}
		}
	
	}

	/**
	 * Returns the list of contacts
	 * @return dm.readFile("contactinfo.txt")
	 */
	public ArrayList<Contact> getWorkingFile() {
		return dm.readFile("contactinfo.txt");
	
	}

	/**
	 * Initalize the file that contains the contacts that will be modified throughout the program
	 */
	
	/*public void setWorkingFile() {
		workingFile =  getWorkingFile();
	}*/
}
			
