package contact;

/**The Person class
 * 
 * @author Rashmi
 *
 */
public class Person{
	protected Name n1;
	protected Gender gen;
	protected long dob;
	

	/**The constructor of the Person class
	 * 
	 * @param fName
	 * @param lName
	 * @param gender
	 * @param birthday
	 */
	public Person(String fName, String lName, Gender gender, long birthday){
		
		n1 = new Name(fName, lName);

		gen = gender;
		
		dob = birthday;
	} 

	
	/**Returns a String, which is the name by combining the first name 
	 *and last name together 
	 * @return name
	 */
	public String getName(){
		String name = "";
		name += n1.getFirstName();
		name += " ";
		name += n1.getLastName();
		return name;
	}
	
	
	/**Changes the last name by accepting a new name as a argument
	 * then calls the changeLastName function in the name class
	 * @param newname
	 */
	public void changeLastName(String newname) {
		n1.changeLastName(newname);
	}

	
	/**Returns the gender of the person which is of type Gender
	 * 
	 * @return gen
	 */
	public Gender getGender(){
		return gen;
	}

	
	/**Returns a birthday of type long for a person
	 * 
	 * @return dob
	 */
	public long getDOB(){
		return dob;
	}
}
