package contact;
/**The Phone class
 * 
 * @author Rashmi and Sanjae
 *
 */
public class Phone {
	private char type;
	private long number; 

	/**The constructor of the Phone class
	 * 
	 * @param phone_n
	 * @param t
	 */
	public Phone(long phone_n, char t){
		number = phone_n;
		type = Character.toUpperCase(t);
	}
		
	/**Returns a integer by using substring the phone number to get the area code,
	 * which is the first 3 digits. Then converts the String to an Integer
	 * @return Integer.parseInt(code)
	 */
	public int getAreaCode(){
		String code = Long.toString(number).substring(0, 3);
		return Integer.parseInt(code);
	}

	/**Returns a character which is the type of phone number entered, whether 
	 * Home(H), Mobile(M) or Work(W)
	 * @return type
	 */
	public char getType(){
		return type;
	}
	
	/**Returns a long, which is the phone number that was given
	 * 
	 * @return
	 */
	public long getNumber(){
		return number;
	}

	/**Returns a String, which is the phone number and the type of phone number
	 * by adding it to String variable
	 * @return details
	 */
	public String toString(){
		String details = "";

		details += "(" + getAreaCode() + ")";
		details += " ";
		details += Long.toString(number).substring(3, 6);
		details += "-";
		details += Long.toString(number).substring(6);

		return details;
	}
}

