//package contact;
//
//import java.util.*;
//import java.io.*;
//
//public class UserInterface{// extends TextInterface, GUI{
//	//public static void main(String[] args) throws IOException {
//		
//		TextInterface txi = new TextInterface();
//		GUI gui = new GUI();
//		
//		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("*********** Welcome ***********");
//		System.out.println("Would you like to continue using the Text Interface or switch to the Graphical Interface (Y/N)");
//		String c = sc.next();
//		
//		if(c.toUpperCase() != "Y") {	//lauches GUI
//			
//		}
//		else if(c.toUpperCase() == "Y") {
//			AddressBook addbk = new AddressBook();
//			DataManager datman = new DataManager();
//			TextInterface.carryoutTextInterface(addbk, datman);	//launches text interface
//		}
//		sc.close(); 
//		
//	}
//}
