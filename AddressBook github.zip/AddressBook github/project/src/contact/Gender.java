package contact;

/**Is an enumerated type that stores two values that can be used
 * as a gender
 * @author Rashmi
 *
 */
public enum Gender {
	MALE, FEMALE
};
