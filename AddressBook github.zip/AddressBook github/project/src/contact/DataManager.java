package contact;
//import static java.nio.file.StandardOpenOption.*;
//import java.nio.file.*;
import java.io.*;
import java.util.*;

/**
 * Manages the files of the Address Book
 * @author Rashmi and Sanjae
 *
 */
public class DataManager {
	ArrayList<Contact> list = new ArrayList<>();
	private String text = "";
	ArrayList<String> al = new ArrayList<>(0);
	
	public DataManager() {

	}
	
//	/**
//	 * Adds information to a file. An appropriate message is displayed when the information has been added
//	 * @param filename
//	 * @param info_forFile
//	 */
//	public void writeToFile(String filename, ArrayList<Contact> list) {
//		String filepath = "C:\\Users\\Rashmi\\Desktop\\Rashmi UWI\\Java Applications\\project\\src\\contact\\";
//		try {
//			//File myObj = new File(filepath + filename);
//			//PrintWriter print_to = new PrintWriter(new FileWriter(filepath +filename), true);
//				BufferedWriter br = new BufferedWriter(new FileWriter((filepath +filename), true));
//				for(Contact info : list) {
//					br.write(info.toString2() + "\n");//\n inside
//				br.close();
//				System.out.println("Information successfully added");
//				}
//		}catch(FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		catch (IOException e) {
//			System.out.println("Error!");
//			e.printStackTrace();
//		}
//	}
//	
//	public void writeToFile2(String filename) {
//		String filepath = "C:\\Users\\Rashmi\\Desktop\\Rashmi UWI\\Java Applications\\project\\src\\contact\\";
//		try {
//			PrintWriter fw = new PrintWriter(new FileWriter(filepath + filename));
//			for (Contact c : list) {
//				System.out.println(c);
//			}
//			for (Contact c : list) {
//
//				adding(c.getName().split(",")[0], c.getName().split(",")[1], c.getGender(), c.getDOB(),
//						c.getEmailList(), c.getAlias(), c.getAddress(), c.getPhoneList(), c.getEntryNo());
//
//			}
//
//			for (String s : al) {
//				text += s + "\n";
//				System.out.print(s);
//			}
//			fw.write(text);
//			fw.close();
//			
//		}catch(FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		catch (IOException e) {
//			System.out.println("Error!");
//			e.printStackTrace();
//		}
//	}

	/**
	 * Adds information to a file. An appropriate message is displayed when the information has been added
	 * @param filename
	 * @param info_forFile
	 */
	public void writeToFile3(String filename, ArrayList<Contact> list) {
		String filepath = "C:\\Users\\Rashmi\\Desktop\\Rashmi UWI\\Java Applications\\project\\src\\contact\\";
		try {
			File myObj = new File(filepath + filename);
			PrintWriter print_to = new PrintWriter(new FileWriter(myObj, true));
			for(Contact info : list) {
				print_to.println(info.toString2());//\n inside
			print_to.close();
			System.out.println("Information successfully added");
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			System.out.println("Error!");
			e.printStackTrace();
		}
	}
	
	/*public ArrayList<Contact> readFile(String filename) {
		ArrayList<Contact> records = new ArrayList<>();
		String filepath = "C:\\Users\\Rashmi\\Desktop\\Rashmi UWI\\Java Applications\\project\\src\\contact\\";
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(filepath + filename));
			String line;
			while ((line = br.readLine()) != null) {
				out.println((line + "\n"));
			}
		}
		br.close();
	}catch (FileNotFoundException e) {
		System.out.println("Error!");
		e.printStackTrace();
	}catch(IOException e) {
		System.out.println("Error");
		e.printStackTrace();
	}
	return records;*/


	//should it return a string so that when we get it we can split it up into the parts required by the person
	/**
	 * Reads information from a file and adds it to a list so that the data can be manipulated. This list is returned. 
	 * @param filename
	 * @return records
	 */
	public ArrayList<Contact> readFile(String filename) {
			ArrayList<Contact> records = new ArrayList<Contact>();
			
			try {
				BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Rashmi\\Desktop\\Rashmi UWI\\Java Applications\\project\\src\\contact\\" + filename));
				String line;
				while ((line = br.readLine()) != null) {
					String[] carray = line.split("%");
			
					int e_number = Integer.parseInt(carray[0]);
					String fname = carray[1];
					String lname = carray[2];
					Gender gend = Gender.valueOf(carray[3]);
					String nickname = carray[4];
					String location = carray[5];
					String phones = carray[6];
					String emails = carray[7];
					//System.out.println(carray[8]);
					Long bday = Long.parseLong(carray[8]);
					
					
					
					Contact c1 = new Contact(fname, lname, gend, nickname, location, bday);
					
					c1.addEmail(emails);
					String[] phone_array = phones.split(",");
					String ty;
					String nu;
					for(int t = 0; t < phone_array.length; t++) {
						ty = phone_array[t].substring(1,2);
						nu = phone_array[t].substring(3,12);
						c1.addPhone(ty.charAt(0), Long.parseLong(nu));
					}
					c1.getEntryNo();
					
					records.add(c1 );	//each time the loop run a line from the file is added as long as it is not empty
				}
				br.close();
			}catch (FileNotFoundException e) {
				System.out.println("Error!");
				e.printStackTrace();
			}catch(IOException e) {
				System.out.println("Error");
				e.printStackTrace();
			}
			return records;
	}
	
	/**
	 * This method is specific for reading the file that contains the list of usernames and passwords
	 * @param filename
	 * @return records
	 */
	public ArrayList<String> readFile2(String filename) {
		ArrayList<String> records = new ArrayList<>();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Rashmi\\Desktop\\Rashmi UWI\\Java Applications\\project\\src\\contact\\" + filename));
			String line;
			while ((line = br.readLine()) != null) {
				String[] carray = line.split("%");
				String username = carray[0];
				String password = carray[1];
				
				records.add(username);
				records.add(password);
			}
			br.close();
		}catch (FileNotFoundException e) {
			System.out.println("Error!");
			e.printStackTrace();
		}catch(IOException e) {
			System.out.println("Error");
			e.printStackTrace();
		}
		return records;
}
	
	/**
	 * Goes through a list and splits the data in it where % is seen. The split data is stored in an array.
	 * The array is returned
	 * @param fileInfo
	 * @return splitString
	 */
	/*public String[] splitInfo(ArrayList<String> fileInfo) {
		String [] splitString = new String[fileInfo.size()];
		//for(String data : fileInfo) {
			for(int i = 0; i < fileInfo.size(); i++) {
				splitString = fileInfo.get(i).split("%");
			}	
		
		return splitString;
	}*/
	
	public void adding(String fname, String lname, Gender gender, long dob, String[] emails, String alias,
					   String[] address, String[] phones, int entryno) {

		String info = fname + "%" + lname + "%" + gender.toString() + "%" + dob + "%" + String.join(",", emails)
				+ "%" + alias + "%" + String.join(";", address) + "%:" + String.join(",", phones) + "%" + entryno;
		al.add(info);
	}

}
