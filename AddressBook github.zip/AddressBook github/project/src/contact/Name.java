package contact;

/**The Name class
 * 
 * @author Rashmi and Sanjae
 *
 */
public class Name {
	private String f_name, l_name;

	/** The constructor for the Name class
	 * 
	 * @param first
	 * @param last
	 */
	public Name(String first, String last) {
		f_name = first;
		l_name = last;
	}

	/**Returns the first name
	 * 
	 * @return 
	 */
	public String getFirstName(){
		return f_name;
	}

	
	/**Returns the last name
	 * 
	 * @return
	 */
	public String getLastName(){
		return l_name;
	}

	
	/**Changes the last name after accepting a new last name
	 * 
	 * @param newName
	 */
	public void changeLastName(String newName){
		l_name = newName; 
	}
}
