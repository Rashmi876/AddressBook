package contact;
import java.io.IOException;
import java.util.*;

/**
 * The textual interface
 * @author Rashmi and Sanjae
 *
 */
public class TextInterface {
	public static void main(String[] args) throws IOException {
		
		/**
		 * This method is going to perform the actions of the text interface when invoke
		 */
		//public static void carryoutTextInterface(AddressBook ab, DataManager dm1) {
			AddressBook ab1 = new AddressBook();
			DataManager dm = new DataManager();
			
			
			//Contact con = new Contact("Rashmi", "Ragbeir", Gender.FEMALE, "Pinky", "71 spoib;bhdh", 1255455L);
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("*********** Welcome ***********");
			System.out.println("");
			
			boolean an = false;
			int count = 0;
			
			while((an == false) && (count < 3)){
				System.out.println("Username: ");
				String uname = sc.next();
				System.out.println("Password: ");
				String pword = sc.next();
				ArrayList<String> info = dm.readFile2("LoginInformation.txt");
				
				for(int i = 0; i < info.size(); i = i+2) {
					//System.out.println(info.get(i));
					//System.out.println(info.get(i + 1));
					if(info.get(i).equals(uname) && info.get(i + 1).equals(pword)) {
						an = true;
						break;
					}
					else {
						an = false;
					}
				}
				count++;
			}
							
			
			/**
			 * The Textual Interface Main Menu
			 */
			if(an == true){
				ArrayList<Contact> contactFile = new ArrayList<>();
				contactFile = ab1.getWorkingFile();
				ArrayList<Contact> clist = new ArrayList<>();
				
				System.out.println("***************************************");
				System.out.println("*************  Main Menu  *************");
				System.out.println("    1 - Create a new contact     	   ");
				System.out.println("    2 - Search for a contact     	   ");
				System.out.println("    3 - Make changes to a contact	   ");
				System.out.println("    4 - Display the list of contacts   ");
				System.out.println("    5 - Delete a contact               ");
				System.out.println("***************************************");
				System.out.println("");
				
				
				/**
				 * Based on the input from the user a specific block of code will be executed
				 */
				switch(sc.nextInt()) {
				/**
				 * Creating a new contact
				 */
				case 1:	
					//dm.clearConsole();
					//System.out.println("\f");
					System.out.println("Creating a new contact\n");
					System.out.println("First Name:");
					String first = sc.next();
					System.out.println("Last Name:");
					String last = sc.next();
					System.out.println("Gender (F/M):");
					Gender gen = null;
					String reply = sc.next().toUpperCase();
					if (reply.equals("F")) {
						gen = Gender.FEMALE;
					}
					else if (reply.equals("M")) {
						gen = Gender.MALE;
					}
					System.out.println("Alias:");
					String nextname = sc.next();
					System.out.println("Put ; for each line for your address");
					System.out.println("Address:" + sc.nextLine());
					String location = sc.nextLine();
					System.out.println("Birthday:");
					long bday = Long.parseLong(sc. next());
					
					ab1.addContact(first, last, gen, nextname, location, bday);
					break;
				/**
				 * Searching for a contact whether by entry # or email address
				 */
				case 2:
					System.out.println("Enter how you would like to search for a contact");
					System.out.println("1 - Search by Entry #");
					System.out.println("2 - Search by Email Address");
					int search = sc.nextInt();
					
					if(search == 1) {
						System.out.println("Enter entry #");
						int key = sc.nextInt();
						ab1.search(key);
					}
					else if(search == 2) {
						System.out.println("Enter email address");
						String key = sc.next();
						ab1.search(key);
					}
					break;
				/**
				 * Making changes to a contact
				 */
				case 3:
					System.out.println("Possible Changes:");
					System.out.println("1 - Last Name");
					System.out.println("2 - Alias");
					System.out.println("3 - Address");
					System.out.println("4 - Add Telephone #");
					System.out.println("5 - Delete Telephone #");
					System.out.println("6 - Add Email Address");
					System.out.println("7 - Delete Email Address\n");
					System.out.println("Entry # for contact that change(s) will be made to");
					int ans = sc.nextInt();
					System.out.println("Change:");
					
					switch(sc.nextInt()) {
					/**
					 * Changing their last name
					 */
					case 1:
						//Contact c2 = new Contact("Rashmi", "Ragbeir", Gender.FEMALE, "Pinky", "12 blue;bh;ded", 2000511L);
						clist = contactFile;
						//System.out.println(c2.getName());
						System.out.println("New last name:");
						ab1.changeLastName(ans, sc.next());
						dm.writeToFile3("contactinfo.txt", clist);
						//System.out.println(c2.getName());
						break;
					/**
					 * Changing their alias
					 */
					case 2:
						clist = contactFile;
						System.out.println("New alias:");
						ab1.changeAlias(ans, sc.next());
						dm.writeToFile3("contactinfo.txt", clist);
						break;
					/**
					 * Changing their address
					 */
					case 3:
						clist = contactFile;
						System.out.println("New address:");
						ab1.changeAddress(ans, sc.next());
						dm.writeToFile3("contactinfo.txt", clist);
						break;
					/**
					 * Adding a telephone #
					 */
					case 4:
						clist = contactFile;
						System.out.println("Telephone # to be added:");
						long num = sc.nextLong();
						System.out.println("Number Type  :  H - Home, W - Work, M - Mobile");
						String type = sc.next();
						ab1.addPhoneNo(ans, num, type.charAt(0));
						dm.writeToFile3("contactinfo.txt", clist);
						break;
					/**
					 * Deleting a telephone #
					 */
					case 5:
						clist = contactFile;
						System.out.println("Telephone # to be deleted:");
						long num2 = sc.nextLong();
						System.out.println("Number Type  :  H - Home, W - Work, M - Mobile");
						String type2 = sc.next();
						ab1.deleteNumber(ans, num2, type2.charAt(0));
						dm.writeToFile3("contactinfo.txt", clist);
						break;
					/**
					 *Adding an email address 
					 */
					case 6:
						clist = contactFile;
						System.out.println("Email Address to be added:");
						ab1.addEmail(ans, sc.next());
						dm.writeToFile3("contactinfo.txt", clist);
						//System.out.println(con);
						break;
					/**
					 * Deleting an email address
					 */
					case 7:
						clist = contactFile;
						System.out.println("Email Address to be deleted:");
						ab1.deleteEmail(ans, sc.next());
						dm.writeToFile3("contactinfo.txt", clist);
						break;
					}	
					break;
				/**
				 * Displaying a contact based on how they are sort, whether by entry # or email address
				 */
				case 4:
					System.out.println("Display Contact sorted by:");
					System.out.println("1 - Entry #");
					System.out.println("2 - Name");
					int n = sc.nextInt();
					
					if(n == 1) {
						ab1.displaybyEntryNo();
					}
					else if(n == 2){
						ab1.displaybyName();
					}
					break;
				/**
				 * Deleting a contact based on an entry # or an email address
				 */
				case 5:
					System.out.println("Delete contact by:");
					System.out.println("1 - Entry #");
					System.out.println("2 - Email Address");
					int delete = sc.nextInt();
					
					if(delete == 1) {
						clist = contactFile;
						System.out.println("Entry #:");
						ab1.deletebyEntryNo(sc.nextInt());
						dm.writeToFile3("contactinfo.txt", clist);
					}
					else if(delete == 2){
						clist = contactFile;
						System.out.println("Email Address:");
						ab1.deletebyEmail(sc.next());
						dm.writeToFile3("contactinfo.txt", clist);
					}
					break;
				}
				//Prompting the user if they would like to save the addressbook data to a file.
				//If yes then write it to a text data file
				System.out.println("Would you like to save changes made to Address Book?");
				System.out.println("1 - Yes");
				System.out.println("2 - No");
				
				if (sc.nextInt() == 1) {
					//save the addressbook to file
					dm.writeToFile3("contactinfo.txt", ab1.getWorkingFile());//, ab1.getContactList()); //how can i send the arraylist
					System.exit(0);
					//close addressbook
				}
				else {
					System.exit(0);
					//just close the addressbook
				}
				sc.close();
				
		}
		else {
			System.out.println("Cannot get in");
			System.exit(0);
		}
	}
	
}


